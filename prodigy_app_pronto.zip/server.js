const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.get('/', (req, res) => {
  res.send('Prodigy App API Running');
});

app.listen(port, () => console.log(`Running on ${port}`));
