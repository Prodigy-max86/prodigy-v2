Prodigy v2 — Final monorepo

What's included:
- server/: Express backend with auth (bcrypt + JWT), AI endpoint, Stripe Checkout + webhook verification, Prisma schema.
- client/: Vite + React landing page (minimalist premium) + Dashboard + Auth.
- render.yaml for easy Render.com deploy.
- .env.example files.

Quick start (local):
1. Create .env in server from .env.example and fill keys.
2. cd server && npm install && npx prisma generate && npx prisma migrate dev --name init
3. cd client && npm install && npm run dev
4. Open http://localhost:5173

Deploy to Render:
1. Push repo to GitHub.
2. In Render, create new service and use render.yaml (Import repository).
3. Set STRIPE_WEBHOOK_SECRET in Render dashboard (for webhook verification).
