import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div className="lp-container">
      <nav className="nav">
        <div className="logo">Prodigy</div>
        <div><Link to='/auth' className="btn-outline">Login</Link></div>
      </nav>
      <header className="hero">
        <h1>Foco. Rotina. Resultados.</h1>
        <p>Prodigy usa IA para criar planos diários, gerir hábitos e maximizar tua produtividade.</p>
        <div className="cta-row">
          <a href="/auth" className="btn">Experimentar grátis</a>
        </div>
      </header>
      <section className="features">
        <div>
          <h3>Planos diários gerados por IA</h3>
          <p>Tarefas prontas com durações e motivação.</p>
        </div>
        <div>
          <h3>Hábitos que funcionam</h3>
          <p>Rastreador simples com lembretes.</p>
        </div>
        <div>
          <h3>Subscrição flexível</h3>
          <p>Pro por €7.99/mês — teste grátis 7 dias.</p>
        </div>
      </section>
      <footer className="footer">
        <small>© Prodigy — 2025</small>
      </footer>
    </div>
  )
}
