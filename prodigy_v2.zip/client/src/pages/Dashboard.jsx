import React, { useState, useEffect } from 'react';
import axios from 'axios';
export default function Dashboard(){
  const [goal,setGoal]=useState(''); const [plan,setPlan]=useState(''); const [tasks, setTasks]=useState([]);
  const token = localStorage.getItem('prodigy_token') || '';
  useEffect(()=>{ async function load(){ 
    if(!token) return; 
    const res = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/tasks', { headers:{ Authorization:'Bearer '+token }});
    setTasks(res.data.tasks || []);
  } load(); }, [token]);
  async function gen(){ const res = await axios.post((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/ai/plan', { goal }, { headers:{ Authorization:'Bearer '+token }}); setPlan(res.data.plan||JSON.stringify(res.data)); }
  async function addTask(){ const title = prompt('Task title'); if(!title) return; await axios.post((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/tasks', { title }, { headers:{ Authorization:'Bearer '+token }}); const r = await axios.get((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/tasks', { headers:{ Authorization:'Bearer '+token }}); setTasks(r.data.tasks||[]); }
  return (
    <div className="dash">
      <header><h1>Dashboard</h1><div><button onClick={()=>{localStorage.removeItem('prodigy_token'); location.href='/'}} className="btn-outline">Logout</button></div></header>
      <section>
        <label>Objetivo</label>
        <input value={goal} onChange={e=>setGoal(e.target.value)} placeholder="Ex: terminar relatório" />
        <button onClick={gen} className="btn">Gerar plano</button>
        <pre style={{whiteSpace:'pre-wrap'}}>{plan}</pre>
      </section>
      <section>
        <h3>Tarefas</h3>
        <button onClick={addTask} className="btn-outline">Adicionar tarefa</button>
        <ul>{tasks.map(t=> (<li key={t.id}>{t.title} {t.done? '✓':''}</li>))}</ul>
      </section>
    </div>
  )
}
