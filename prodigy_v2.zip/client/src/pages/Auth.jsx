import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Auth(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();
  async function signup(){
    const res = await axios.post((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/auth/signup', { email, password });
    localStorage.setItem('prodigy_token', res.data.token);
    nav('/dashboard');
  }
  async function login(){
    const res = await axios.post((import.meta.env.VITE_API_URL||'http://localhost:4000') + '/api/auth/login', { email, password });
    localStorage.setItem('prodigy_token', res.data.token);
    nav('/dashboard');
  }
  return (
    <div className="auth">
      <h2>Login / Signup</h2>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <div className="auth-row">
        <button onClick={login} className="btn">Login</button>
        <button onClick={signup} className="btn-outline">Signup</button>
      </div>
    </div>
  )
}
