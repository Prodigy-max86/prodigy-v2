Prodigy Server (v2)

Setup:
1. copy .env.example to .env and fill values (OPENAI_KEY, DATABASE_URL, JWT_SECRET, STRIPE keys, FRONTEND_URL)
2. npm install
3. npx prisma generate
4. npx prisma migrate dev --name init
5. npm run dev

Security notes:
- Ensure STRIPE_WEBHOOK_SECRET is set and webhook endpoint uses raw body as implemented.
- Use HTTPS in production and keep JWT_SECRET secure.
