import fetch from 'node-fetch';
import jwt from 'jsonwebtoken';
const OPENAI_KEY = process.env.OPENAI_KEY;

function getUserIdFromHeader(req){
  const auth = req.headers.authorization;
  if(!auth) return null;
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    return payload.userId;
  } catch(e){
    return null;
  }
}

export async function generatePlan(req, res){
  const userId = getUserIdFromHeader(req);
  if(!userId) return res.status(401).json({ error: 'unauthorized' });
  const { goal, constraints } = req.body;
  if(!goal) return res.status(400).json({ error: 'goal required' });
  const prompt = `You are Prodigy, an assistant. Create a concise daily plan for the goal: ${goal}. Constraints: ${constraints || 'none'}. Provide 5 tasks with durations and short motivation.`;
  try{
    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'Authorization': `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify({ model: 'gpt-4o-mini', input: prompt, max_output_tokens: 800 })
    });
    const data = await r.json();
    let text = '';
    if(data.output && Array.isArray(data.output) && data.output[0].content){
      for(const c of data.output[0].content){
        if(typeof c === 'string') text += c;
        else if(c.text) text += c.text;
      }
    } else if(data.choices && data.choices[0] && data.choices[0].message){
      text = data.choices[0].message.content;
    } else {
      text = JSON.stringify(data);
    }
    return res.json({ plan: text });
  }catch(e){
    console.error('OpenAI error', e);
    return res.status(500).json({ error: 'openai error' });
  }
}
