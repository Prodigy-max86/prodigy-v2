import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2022-11-15' });

export async function createCheckoutSession(req, res){
  const { priceId, successUrl, cancelUrl, email } = req.body;
  if(!priceId || !successUrl) return res.status(400).json({ error: 'priceId and successUrl required' });
  try{
    // Create or retrieve customer by email
    let customer;
    if(email){
      const existing = await stripe.customers.list({ email, limit:1 });
      customer = existing.data[0];
    }
    if(!customer){
      customer = await stripe.customers.create({ email });
    }
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer: customer.id,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl
    });
    res.json({ url: session.url, id: session.id });
  }catch(e){
    console.error('stripe create session error', e);
    res.status(500).json({ error: 'stripe error' });
  }
}

export async function stripeWebhook(req, res){
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event;
  try{
    event = stripe.webhooks.constructEvent(req.rawBody, sig, webhookSecret);
  }catch(e){
    console.error('Webhook signature verification failed.', e.message);
    return res.status(400).send(`Webhook Error: ${e.message}`);
  }
  // Handle event types
  switch(event.type){
    case 'checkout.session.completed':
      // Attach subscription to user on next step using metadata or lookup by customer email
      console.log('checkout.session.completed', event.data.object.id);
      break;
    case 'invoice.payment_succeeded':
      console.log('invoice.payment_succeeded', event.data.object.id);
      break;
    case 'customer.subscription.deleted':
      console.log('subscription cancelled', event.data.object.id);
      break;
    default:
      console.log('Unhandled event', event.type);
  }
  res.json({ received: true });
}
