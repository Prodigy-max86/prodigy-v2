import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';
const prisma = new PrismaClient();

function getUserId(req){
  const auth = req.headers.authorization;
  if(!auth) return null;
  const token = auth.split(' ')[1];
  try { return jwt.verify(token, process.env.JWT_SECRET || 'dev_secret').userId; } catch(e) { return null; }
}

export async function listTasks(req, res){
  const userId = getUserId(req);
  if(!userId) return res.status(401).json({ error: 'unauthorized' });
  const tasks = await prisma.task.findMany({ where: { userId }});
  res.json({ tasks });
}

export async function createTask(req, res){
  const userId = getUserId(req);
  if(!userId) return res.status(401).json({ error: 'unauthorized' });
  const { title, dueAt } = req.body;
  if(!title) return res.status(400).json({ error: 'title required' });
  const t = await prisma.task.create({ data: { userId, title, dueAt: dueAt ? new Date(dueAt) : null }});
  res.json({ task: t });
}
