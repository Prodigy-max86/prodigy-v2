import express from 'express';
import { generatePlan } from '../controllers/aiController.js';
const router = express.Router();

router.post('/plan', generatePlan);

export default router;
