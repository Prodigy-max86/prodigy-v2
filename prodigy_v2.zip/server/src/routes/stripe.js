import express from 'express';
import { stripeWebhook, createCheckoutSession } from '../controllers/stripeController.js';
const router = express.Router();

router.post('/webhook', stripeWebhook);
router.post('/create-checkout-session', createCheckoutSession);

export default router;
