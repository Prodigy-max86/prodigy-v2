import express from 'express';
import { listTasks, createTask } from '../controllers/tasksController.js';
const router = express.Router();

router.get('/', listTasks);
router.post('/', createTask);

export default router;
