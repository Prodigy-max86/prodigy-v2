import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import authRoutes from './routes/auth.js';
import aiRoutes from './routes/ai.js';
import taskRoutes from './routes/tasks.js';
import stripeRoutes from './routes/stripe.js';

dotenv.config();
const app = express();
const prisma = new PrismaClient();

app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173'
}));
app.use(bodyParser.json({
  verify: (req, res, buf) => {
    // store raw body for stripe webhook verification
    req.rawBody = buf.toString();
  }
}));

// Basic rate limiter
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120
});
app.use(limiter);

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date() }));

app.use('/api/auth', authRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/stripe', stripeRoutes);

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('Prodigy server listening on', port));
